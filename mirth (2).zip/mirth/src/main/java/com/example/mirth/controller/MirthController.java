package com.example.mirth.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.io.*;
import java.net.Socket;
import java.nio.file.Files;

@RestController
public class MirthController {
    @Autowired
    RestTemplate restTemplate;

    @GetMapping("/mirth-tcp-json")
    public void tcpChannelJsonSender(){
    try {
        /*String content = new String("D:\\converter\\sample.json");
        System.out.println(content);
        Socket s = new Socket("127.0.0.1",6661);
        DataOutputStream dout = new DataOutputStream(s.getOutputStream());
        dout.writeUTF(content);*/
        String str = "{ \"name : \"Hello\" }";
        File file = new File("D:\\converter\\sample.json");
        Socket s = new Socket("127.0.0.1",6661);
        DataOutputStream dout = new DataOutputStream(s.getOutputStream());
        Files.copy(file.toPath(), dout);
        //dout.writeUTF(str);
        dout.flush();
        dout.close();
        s.close();
    } catch (Exception e){
        e.printStackTrace();
    }
    }

    @PostMapping("/mirth-receiver")
    public void receiverHL7(@RequestBody String body){
        System.out.println("Called");
        System.out.println(body);
        try (PrintWriter out = new PrintWriter("D:\\converter\\Dtv.hl7")) {
            out.println(body);
        } catch (FileNotFoundException fe) {
            fe.printStackTrace();
        }
    }

    @GetMapping("/mirth-tcp-hl7")
    public void tcpChannelHL7Sender(){
        try {
            String str = "{ \"name : \"Hello\" }";
            File file = new File("D:\\converter\\sample.json");
            Socket s = new Socket("127.0.0.1",6661);
            DataOutputStream dout = new DataOutputStream(s.getOutputStream());
            Files.copy(file.toPath(), dout);
            //dout.writeUTF(str);
            dout.flush();
            dout.close();
            s.close();
        } catch (Exception e){
            e.printStackTrace();
        }
    }

}
